package com.example.suportstudy.model

data  class CourseType (var _id:String, val name:String,var image:String,var description:String)