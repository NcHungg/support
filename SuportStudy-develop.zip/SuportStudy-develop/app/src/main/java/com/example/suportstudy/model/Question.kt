package com.example.suportstudy.model

data class Question (
    var _id:String,
    var title:String,
    var option1:String,
    var option2:String,
    var option3:String,
    var option4:String,
    var trueOption:Int
        )