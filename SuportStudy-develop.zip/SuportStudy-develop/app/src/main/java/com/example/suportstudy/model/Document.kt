package com.example.suportstudy.model

data  class Document(
    var title: String,
    var image: String
)