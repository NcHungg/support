package com.example.suportstudy.model

data  class Chatlist (var id:String?=null)