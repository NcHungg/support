package com.example.suportstudy.model

data class Participant (
    var _id:String?=null,
    var uid:String?=null,
    var jointime:String?=null
)